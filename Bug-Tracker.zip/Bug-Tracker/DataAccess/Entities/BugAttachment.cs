﻿#nullable disable
namespace DataAccess;

public class BugAttachment
{
    public int AttachmentID { get; set; }
    public int BugID { get; set; }
    public string FileName { get; set; }
    public string FilePath { get; set; }
    public DateTime UploadDate { get; set; }

    // Navigation property for one-to-many relationship (Bug)
    public Bug Bug { get; set; }
}

