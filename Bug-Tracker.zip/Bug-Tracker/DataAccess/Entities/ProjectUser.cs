﻿#nullable disable


namespace DataAccess;

public class ProjectUser
{
    public int ProjectID { get; set; }
    public int UserID { get; set; }

    // Navigation properties for many-to-many relationships (Projects and Users)
    public Project Project { get; set; }
    public User User { get; set; }

    public static implicit operator int(ProjectUser v)
    {
        return v.UserID;
    }
}

