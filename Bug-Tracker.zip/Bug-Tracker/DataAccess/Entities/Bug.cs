﻿#nullable disable
namespace DataAccess;

public class Bug
{
    public int BugID { get; set; }
    public string Title { get; set; }
    public string Description { get; set; }
    public string Status { get; set; }
    public string Severity { get; set; }
    public DateTime CreatedDate { get; set; }
    public DateTime ResolvedDate { get; set; }

    // Foreign key for one-to-one relationship (Project)
    public int ProjectID { get; set; }
    // Navigation property for one-to-one relationship (Project)
    public Project Project { get; set; }

    // Navigation property for one-to-many relationship (Comments)
    public ICollection<Comment> Comments { get; set; }

    // Navigation property for one-to-many relationship (BugAttachments)
    public ICollection<BugAttachment> BugAttachments { get; set; }

    // Navigation property for many-to-many relationship (BugUsers)
    public ICollection<BugUser> BugUsers { get; set; }
}
