﻿#nullable disable


namespace DataAccess;

public class BugUser
{
    public int BugID { get; set; }
    public int UserID { get; set; }

    // Navigation properties for many-to-many relationships (Bugs and Users)
    public Bug Bug { get; set; }
    public User User { get; set; }

    public static implicit operator int(BugUser v)
    {
        return v.UserID;
    }
}

