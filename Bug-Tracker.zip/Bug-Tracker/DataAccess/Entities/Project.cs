﻿#nullable disable
namespace DataAccess;

public class Project
{
    public int ProjectID { get; set; }
    public string ProjectName { get; set; }
    public string Description { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }

    // Navigation property for many-to-many relationship (ProjectUsers)
    public ICollection<ProjectUser> ProjectUsers { get; set; }

    // Navigation property for one-to-one relationship (Bug)
    public Bug Bug { get; set; }
}
