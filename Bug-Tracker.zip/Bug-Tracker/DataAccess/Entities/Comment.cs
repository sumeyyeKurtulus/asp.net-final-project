﻿#nullable disable
namespace DataAccess;

public class Comment
{
    public int CommentID { get; set; }
    public int BugID { get; set; }
    public int UserID { get; set; }
    public string CommentText { get; set; }
    public DateTime CommentDate { get; set; }

    // Navigation properties for one-to-many relationships (Bugs and Users)
    public Bug Bug { get; set; }
    public User User { get; set; }
}

