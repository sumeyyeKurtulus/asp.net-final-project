﻿using Microsoft.EntityFrameworkCore;

namespace DataAccess;

public class Db : DbContext 
{
    public DbSet<Bug> Bugs { get; set; }
    public DbSet<Comment> Comments { get; set; }
    public DbSet<Project> Projects { get; set; }
    public DbSet<User> Users { get; set; }
    public DbSet<BugAttachment> BugAttachments { get; set; }
    public DbSet<BugUser> BugUsers { get; set; }
    public DbSet<ProjectUser> ProjectUsers { get; set; }


    public Db(DbContextOptions options) : base(options)
    {
    }
	
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<BugUser>().HasKey(e =>  new { e.UserID, e.BugID }); 
        modelBuilder.Entity<ProjectUser>().HasKey(e =>  new { e.UserID, e.ProjectID }); 
        modelBuilder.Entity<BugAttachment>().HasKey(e =>  new { e.AttachmentID, e.BugID }); 
    }
}
