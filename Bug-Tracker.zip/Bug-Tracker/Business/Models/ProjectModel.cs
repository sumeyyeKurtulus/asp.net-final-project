﻿#nullable disable
using System.ComponentModel;
using DataAccess;

namespace Business;

public class ProjectModel
{
    public int ProjectID { get; set; }

    [DisplayName("Project Name")]
    public string ProjectName { get; set; }
    public string Description { get; set; }

    [DisplayName("Start Date")]
    public DateTime StartDate { get; set; }

    [DisplayName("End Date")]
    public DateTime EndDate { get; set; }

    // Navigation property for many-to-many relationship (ProjectUsers)
    public ICollection<ProjectUser> ProjectUsers { get; set; }

    // Navigation property for one-to-one relationship (Bug)
    public Bug Bug { get; set; }
}
