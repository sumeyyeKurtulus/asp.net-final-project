﻿#nullable disable
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using DataAccess;

namespace Business;

public class CommentModel
{
    public int CommentID { get; set; }
    [DisplayName("Bug")]
    public int BugID { get; set; }
    [DisplayName("User")]
    public int UserID { get; set; }

    [DisplayName("Comment")]
    public string CommentText { get; set; }
    
    [DisplayName("Date")]
    public DateTime CommentDate { get; set; }

    // Navigation properties for one-to-many relationships (Bugs and Users)
    public Bug Bug { get; set; }
    public User User { get; set; }
}
