﻿#nullable disable
using System.ComponentModel;
using DataAccess;

namespace Business;

public class UserModel
{
    public int UserID { get; set; }

    [DisplayName("User Name")]
    public string UserName { get; set; }
    public string Email { get; set; }
    public string Password { get; set; }

    [DisplayName("First Name")]
    public string FirstName { get; set; }

    [DisplayName("Last Name")]
    public string LastName { get; set; }

    // Navigation property for many-to-many relationship (BugUsers)
    [DisplayName("Reported Bugs")]
    public ICollection<BugUser> BugUsers { get; set; }

    // Navigation property for many-to-many relationship (ProjectUsers)
    [DisplayName("Projects")]
    public ICollection<ProjectUser> ProjectUsers { get; set; }

    // Navigation property for one-to-many relationship (Comments)
    public ICollection<Comment> Comments { get; set; }
}
