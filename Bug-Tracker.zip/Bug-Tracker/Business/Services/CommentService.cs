﻿#nullable disable
using Business.Results;
using Business.Results.Bases;
using DataAccess;

namespace Business;

public interface ICommentService {
    IQueryable<CommentModel> Query();
    Result Add(CommentModel model);
    Result Update(CommentModel model);
    Result Delete(int id);
    List<CommentModel> GetList();
    CommentModel GetItem(int id);

}

public class CommentService: ICommentService
{
    private readonly Db _db;

    public CommentService(Db db)
    {   
        _db = db;
    }

    public IQueryable<CommentModel> Query()
    {
        return _db.Comments.OrderBy(c => c.CommentID).Select(c => new CommentModel()
        {
            CommentID = c.CommentID,
            BugID = c.BugID,
            UserID = c.UserID,
            CommentText = c.CommentText,
            CommentDate = c.CommentDate,
            Bug = c.Bug,
            User = c.User
        });
    }

    public Result Add(CommentModel model)
    {

        var entity = new Comment()
        {
            CommentText = model.CommentText,
            CommentDate = model.CommentDate,
            BugID = model.BugID,
            UserID = model.UserID
        };

        _db.Comments.Add(entity);
        _db.SaveChanges();
        return new SuccessResult("Comment is added successfully.");
    }

    //Update Comment
    public Result Update(CommentModel model)
    {
        var existingEntity = 
            _db.Comments.SingleOrDefault(u => u.CommentID == model.CommentID);

        existingEntity.CommentText = model.CommentText;
        existingEntity.CommentDate = model.CommentDate;

        _db.Comments.Update(existingEntity);
        _db.SaveChanges(); 
        return new SuccessResult("Comment is updated successfully.");
    }

    //Delete Comment
    public Result Delete(int id)
    {
        var entity = _db.Comments.SingleOrDefault(u => u.CommentID == id);

        if (entity is null)
            return new ErrorResult("Comment is not found!");
        
        _db.Comments.Remove(entity);
        _db.SaveChanges();
        return new SuccessResult("Comment is deleted successfully.");
    }

    public List<CommentModel> GetList()
    {
        return Query().ToList();
    }

    public CommentModel GetItem(int id) => Query().SingleOrDefault(c => c.CommentID == id);

}
