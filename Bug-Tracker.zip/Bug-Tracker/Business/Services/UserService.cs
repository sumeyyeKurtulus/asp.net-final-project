﻿#nullable disable
using Business.Results;
using Business.Results.Bases;
using DataAccess;
using Microsoft.EntityFrameworkCore;

namespace Business;

public interface IUserService {
    IQueryable<UserModel> Query();
    Result Add(UserModel model);
    Result Update(UserModel model);
    Result Delete(int id);
    List<UserModel> GetList();
    UserModel GetItem(int id);

}

public class UserService: IUserService
{
    private readonly Db _db;

    public UserService(Db db)
    {   
        _db = db;
    }

    public IQueryable<UserModel> Query()
    {
        return _db.Users.OrderBy(u => u.UserName).Select(u => new UserModel()
        {
            UserID = u.UserID,
            UserName = u.UserName,
            FirstName = u.FirstName,
            LastName = u.LastName, 
            Email = u.Email,
            Password = u.Password,
            Comments = u.Comments,
            BugUsers = u.BugUsers,
            ProjectUsers = u.ProjectUsers
        });
    }


    // Add User
    public Result Add(UserModel model)
    {

        var entity = new User()
        {

            UserName = model.UserName,
            FirstName = model.FirstName,
            LastName = model.LastName,
            Email = model.Email,
            Password = model.Password,
            Comments =model.Comments,
            ProjectUsers = model.ProjectUsers?.Select(userID => new ProjectUser()
            {
                UserID = userID
            }).ToList(),
            BugUsers = model.BugUsers?.Select(userID => new BugUser()
            {
                UserID = userID
            }).ToList()
        };

        _db.Users.Add(entity);
        _db.SaveChanges();
        return new SuccessResult("User is added successfully.");
    }


    //Update User
    public Result Update(UserModel model)
    {
        var existingEntity = 
            _db.Users
                .Include(u => u.ProjectUsers)
                .Include(u => u.BugUsers)
                .SingleOrDefault(u => u.UserID == model.UserID);

        if (existingEntity is not null && existingEntity.ProjectUsers is not null)
            _db.ProjectUsers.RemoveRange(existingEntity.ProjectUsers);
        
        if (existingEntity is not null && existingEntity.BugUsers is not null)
            _db.BugUsers.RemoveRange(existingEntity.BugUsers);

        existingEntity.ProjectUsers = model.ProjectUsers?.Select(userId => new ProjectUser()
        {
            UserID = userId
        }).ToList();

        existingEntity.BugUsers = model.BugUsers?.Select(userId => new BugUser()
        {
            UserID = userId
        }).ToList();

        existingEntity.FirstName = model.FirstName;
        existingEntity.LastName = model.LastName;
        existingEntity.UserName = model.UserName;
        existingEntity.Comments = model.Comments;
        existingEntity.Email = model.Email;

        _db.Users.Update(existingEntity);
        _db.SaveChanges(); 
        return new SuccessResult("Project is updated successfully.");
    }

    //Delete User
    public Result Delete(int id)
    {
        var entity = _db.Users
            .Include(u => u.ProjectUsers)
            .Include(u => u.BugUsers)
            .SingleOrDefault(u => u.UserID == id);

        if (entity is null)
            return new ErrorResult("User not found!");
        
        _db.ProjectUsers.RemoveRange(entity.ProjectUsers);
        _db.BugUsers.RemoveRange(entity.BugUsers);

        _db.Users.Remove(entity);
        _db.SaveChanges();
        return new SuccessResult("Project is deleted successfully.");
    }

    public List<UserModel> GetList()
    {
        return Query().ToList();
    }

    public UserModel GetItem(int id) => Query().SingleOrDefault(u => u.UserID == id);

}

