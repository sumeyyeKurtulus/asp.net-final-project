﻿#nullable disable
using Business.Results;
using Business.Results.Bases;
using DataAccess;
using Microsoft.EntityFrameworkCore;

namespace Business;

public interface IProjectService {
    IQueryable<ProjectModel> Query();
    Result Add(ProjectModel model);
    Result Update(ProjectModel model);
    Result Delete(int id);
    List<ProjectModel> GetList();
    ProjectModel GetItem(int id);

}

public class ProjectService: IProjectService
{
    private readonly Db _db;

    public ProjectService(Db db)
    {   
        _db = db;
    }

    //Query to get the project list
    public IQueryable<ProjectModel> Query()
    {
        return _db.Projects.OrderBy(p => p.ProjectName).Select(p => new ProjectModel()
        {
            ProjectID = p.ProjectID,
            ProjectName = p.ProjectName,
            Description = p.Description,
            ProjectUsers = p.ProjectUsers,
            StartDate = p.StartDate,
            EndDate = p.EndDate,
            Bug = p.Bug
        });
    }

    //Add Project
    public Result Add(ProjectModel model)
    {

        var entity = new Project()
        {
            ProjectID = model.ProjectID,
            ProjectName = model.ProjectName,
            Description = model.Description,
            StartDate = model.StartDate,
            EndDate = model.EndDate,
            Bug = model.Bug,
            ProjectUsers = model.ProjectUsers?.Select(userId => new ProjectUser()
            {
                UserID = userId
            }).ToList()
        };
        _db.Projects.Add(entity);
        _db.SaveChanges();
        return new SuccessResult("Project is added successfully.");
    }


    //Update Project
    public Result Update(ProjectModel model)
    {
        var existingEntity = _db.Projects.Include(p => p.ProjectUsers).SingleOrDefault(p => p.ProjectID == model.ProjectID);
        if (existingEntity is not null && existingEntity.ProjectUsers is not null)
            _db.ProjectUsers.RemoveRange(existingEntity.ProjectUsers);

        existingEntity.ProjectName = model.ProjectName?.Trim();
        existingEntity.ProjectUsers = model.ProjectUsers?.Select(userId => new ProjectUser()
        {
            UserID = userId
        }).ToList();
        existingEntity.StartDate = model.StartDate;
        existingEntity.EndDate = model.EndDate;
        existingEntity.Description = model.Description.Trim();
        _db.Projects.Update(existingEntity);
        _db.SaveChanges(); 
        return new SuccessResult("Project is updated successfully.");
    }

    //Delete Project
    public Result Delete(int id)
    {
        var entity = _db.Projects.Include(r => r.ProjectUsers).SingleOrDefault(r => r.ProjectID == id);
        if (entity is null)
            return new ErrorResult("User not found!");
        _db.ProjectUsers.RemoveRange(entity.ProjectUsers);
        _db.Projects.Remove(entity);
        _db.SaveChanges();
        return new SuccessResult("Project is deleted successfully.");
    }

    public List<ProjectModel> GetList()
    {
        return Query().ToList();
    }

    public ProjectModel GetItem(int id) => Query().SingleOrDefault(r => r.ProjectID == id);

}
