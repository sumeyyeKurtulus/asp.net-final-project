﻿#nullable disable
using Business.Results;
using Business.Results.Bases;
using DataAccess;
using Microsoft.EntityFrameworkCore;

namespace Business;

public interface IBugService {
    IQueryable<BugModel> Query();
    Result Add(BugModel model);
    Result Update(BugModel model);
    Result Delete(int id);
    List<BugModel> GetList();
    BugModel GetItem(int id);
}

public class BugService: IBugService
{
    private readonly Db _db;

    public BugService(Db db)
    {   
        _db = db;
    }

    public IQueryable<BugModel> Query()
    {
        return _db.Bugs.OrderBy(b => b.CreatedDate).Select(b => new BugModel()
        {
            BugID = b.BugID,
            Title = b.Title,
            Description = b.Description,
            Status = b.Status,
            Severity = b.Severity,
            CreatedDate = b.CreatedDate,
            ResolvedDate = b.ResolvedDate,
            ProjectID = b.ProjectID,
            Project = b.Project,
            Comments = b.Comments,
            BugAttachments = b.BugAttachments,
            BugUsers = b.BugUsers,
        });
    }


     // Add Bug
    public Result Add(BugModel model)
    {
        var entity = new Bug()
        {
            Title = model.Title,
            Description = model.Description,
            Status = model.Status,
            Severity = model.Severity,
            CreatedDate = model.CreatedDate,
            ResolvedDate = model.ResolvedDate,
            ProjectID = model.ProjectID,
            Project = model.Project,
            Comments = model.Comments,
            BugAttachments = model.BugAttachments,

            BugUsers = model.BugUsers?.Select(userID => new BugUser()
            {
                UserID = userID
            }).ToList(),

        };

        _db.Bugs.Add(entity);
        _db.SaveChanges();
        return new SuccessResult("Bug is added successfully.");
    }


    
    //Update Bug
    public Result Update(BugModel model)
    {
        var existingEntity = 
            _db.Bugs
                .Include(u => u.BugUsers)
                .SingleOrDefault(u => u.BugID == model.BugID);
        
        if (existingEntity is not null && existingEntity.BugUsers is not null)
            _db.BugUsers.RemoveRange(existingEntity.BugUsers);

        existingEntity.BugUsers = model.BugUsers?.Select(userId => new BugUser()
        {
            UserID = userId
        }).ToList();

        existingEntity.Title = model.Title;
        existingEntity.Description = model.Description;
        existingEntity.Status = model.Status;
        existingEntity.Severity = model.Severity;
        existingEntity.CreatedDate = model.CreatedDate;
        existingEntity.ResolvedDate = model.ResolvedDate;
        existingEntity.Project = model.Project;
        existingEntity.Comments = model.Comments;
        existingEntity.BugAttachments = model.BugAttachments;

        _db.Bugs.Update(existingEntity);
        _db.SaveChanges(); 

        return new SuccessResult("Bug is updated successfully.");
    }

     //Delete Bug
    public Result Delete(int id)
    {
        var entity = _db.Bugs
            .Include(u => u.BugUsers)
            .SingleOrDefault(u => u.BugID == id);

        if (entity is null)
            return new ErrorResult("Bug not found!");
        
        _db.BugUsers.RemoveRange(entity.BugUsers);

        _db.Bugs.Remove(entity);
        _db.SaveChanges();
        return new SuccessResult("Bug is deleted successfully.");
    }

    public List<BugModel> GetList()
    {
        return Query().ToList();
    }

    public BugModel GetItem(int id) => Query().SingleOrDefault(u => u.BugID == id);

}

