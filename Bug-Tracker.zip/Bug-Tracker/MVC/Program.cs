#nullable disable
using Business;
using DataAccess;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

#region AppSettings
    var section = builder.Configuration.GetSection(nameof(MVC.Settings.AppSettings));
    section.Bind(new MVC.Settings.AppSettings());
#endregion

#region IOC
    builder.Services.AddDbContext<Db>(options => options.UseMySQL(builder.Configuration.GetConnectionString("DefaultConnection")));
    builder.Services.AddScoped<IBugService, BugService>();
    builder.Services.AddScoped<ICommentService, CommentService>();
    builder.Services.AddScoped<IProjectService, ProjectService>();
    builder.Services.AddScoped<IUserService, UserService>();
#endregion

#region Authentication
    builder.Services
        .AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)

        .AddCookie(config =>

        {
            config.LoginPath = "/Account/Login";

            config.AccessDeniedPath = "/Account/AccessDenied";

            // config.ExpireTimeSpan = TimeSpan.FromMinutes(AppSettings.CookieExpirationInMinutes);

            config.SlidingExpiration = true;
        });
#endregion

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

#region Authentication
app.UseAuthentication();
#endregion

app.UseAuthorization();

app.UseAuthorization();

app.MapControllerRoute(name: "register",
    pattern: "register",
    defaults: new { controller = "Users", action = "Create" });

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
