#nullable disable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using DataAccess;
using Business;

//Generated from Custom Template.
namespace MVC.Controllers
{
    public class CommentsController : Controller
    {
        // TODO: Add service injections here
        private readonly ICommentService _commentService;
        private readonly IBugService _bugService;
        private readonly IUserService _userService;

        public CommentsController(
            ICommentService commentService,
            IBugService bugService,
            IUserService userService
        )
        {
            _commentService = commentService;
            _bugService = bugService;
            _userService = userService;
        }

        // GET: Comments
        public IActionResult Index()
        {
            List<CommentModel> commentList = _commentService.GetList();
            return View(commentList);
        }

        // GET: Comments/Details/5
        public IActionResult Details(int id)
        {
            CommentModel user = _commentService.GetItem(id);
            if (user == null)
            {
                return View("_Error", "Comment not found!");
            }
            return View(user);
        }

        // GET: Comments/Create
        public IActionResult Create()
        {
            ViewBag.UserID = new MultiSelectList(_userService.Query().ToList(), "UserID", "UserName");
            ViewBag.BugID = new MultiSelectList(_bugService.Query().ToList(), "BugID", "Title");
            return View();
        }

        // POST: Comments/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(CommentModel comment)
        {
            if (ModelState.IsValid)
            {
                var result = _commentService.Add(comment);
                if (result.IsSuccessful)
                {
                    TempData["Message"] = result.Message;
                    return RedirectToAction(nameof(Index));
                }
                ModelState.AddModelError("", result.Message);
            }
        
            // Assuming you are passing BugID and UserID in your CommentModel
            ViewBag.UserID = new SelectList(_userService.Query().ToList(), "UserID", "UserName", comment.UserID);
            ViewBag.BugID = new SelectList(_bugService.Query().ToList(), "BugID", "Title", comment.BugID);
            return View(comment);
        }

        // GET: Comments/Edit/5
        public IActionResult Edit(int id)
        {
            CommentModel comment = _commentService.GetItem(id);
            if (comment == null)
            {
                return View("_Error", "Comment not found!");
			}

            ViewBag.UserID = new MultiSelectList(_userService.Query().ToList(), "UserID", "UserName");
            ViewBag.BugID = new MultiSelectList(_bugService.Query().ToList(), "BugID", "Title");

            return View(comment);
        }

        // POST: Comments/Edit
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(CommentModel comment)
        {
            if (ModelState.IsValid)
            {
                var result = _commentService.Update(comment);
                if (result.IsSuccessful)
                {
					TempData["Message"] = result.Message;
                    return RedirectToAction(nameof(Details), new { id = comment.CommentID });
				}
                ModelState.AddModelError("", result.Message);
            }
            
            ViewBag.UserID = new SelectList(_userService.Query().ToList(), "UserID", "UserName", comment.UserID);
            ViewBag.BugID = new SelectList(_bugService.Query().ToList(), "BugID", "Title", comment.BugID);

            return View(comment);
        }

        // GET: Comments/Delete/5
        public IActionResult Delete(int id)
        {
            var result = _commentService.Delete(id);
			TempData["Message"] = result.Message;
			return RedirectToAction(nameof(Index));
        }

        // POST: Comments/Delete
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            // TODO: Add delete service logic here
            return RedirectToAction(nameof(Index));
        }
	}
}
