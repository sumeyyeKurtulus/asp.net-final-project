#nullable disable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using DataAccess;
using Business;

//Generated from Custom Template.
namespace MVC.Controllers
{
    public class UsersController : Controller
    {
        // TODO: Add service injections here
        private readonly IUserService _userService;
        private readonly IProjectService _projectService;
        private readonly IBugService _bugService;


        public UsersController(
            IUserService userService, 
            IProjectService projectService,
            IBugService bugService
        )
        {
            _userService = userService;
            _projectService = projectService;
            _bugService = bugService;
        }

        // GET: Users
        public IActionResult Index()
        {
            List<UserModel> userList = _userService.GetList();
            return View(userList);
        }

        // GET: Users/Details/5
        public IActionResult Details(int id)
        {
            UserModel user = _userService.GetItem(id);
            if (user == null)
            {
                return View("_Error", "User not found!");
            }
            return View(user);
        }

        // GET: Users/Create
        public IActionResult Create()
        {
            ViewBag.ProjectID = new MultiSelectList(_projectService.Query().ToList(), "ProjectID", "ProjectName");
            ViewBag.BugID = new MultiSelectList(_bugService.Query().ToList(), "BugID", "Title");
            return View();
        }

        // POST: Users/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(UserModel user)
        {
            if (ModelState.IsValid)
            {
                var result = _userService.Add(user);
                if (result.IsSuccessful)
                {
					TempData["Message"] = result.Message;
					return RedirectToAction(nameof(Index));
                }
                ModelState.AddModelError("", result.Message);
            }
            ViewBag.ProjectID = new MultiSelectList(_projectService.Query().ToList(), "ProjectID", "ProjectName");
            ViewBag.BugID = new MultiSelectList(_bugService.Query().ToList(), "BugID", "Title");
			return View(user);
        }

        // GET: Users/Edit/5
        public IActionResult Edit(int id)
        {
            UserModel user = _userService.GetItem(id);
            if (user == null)
            {
                return View("_Error", "User not found!");
			}
            ViewBag.ProjectID = new MultiSelectList(_projectService.Query().ToList(), "ProjectID", "ProjectName");
            ViewBag.BugID = new MultiSelectList(_bugService.Query().ToList(), "BugID", "Title");
			return View(user);
        }

        // POST: Users/Edit
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(UserModel user)
        {
            if (ModelState.IsValid)
            {
                var result = _userService.Update(user);
                if (result.IsSuccessful)
                {
					TempData["Message"] = result.Message;
                    return RedirectToAction(nameof(Details), new { id = user.UserID });
				}
                ModelState.AddModelError("", result.Message);
            }
            ViewBag.ProjectID = new MultiSelectList(_projectService.Query().ToList(), "ProjectID", "ProjectName");
            ViewBag.BugID = new MultiSelectList(_bugService.Query().ToList(), "BugID", "Title");
			return View(user);
        }

        // GET: Users/Delete/5
        public IActionResult Delete(int id)
        {
            var result = _userService.Delete(id);
			TempData["Message"] = result.Message;
			return RedirectToAction(nameof(Index));

        }

        // POST: Users/Delete
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            // TODO: Add delete service logic here
            return RedirectToAction(nameof(Index));
        }
	}
}
