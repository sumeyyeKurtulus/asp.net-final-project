#nullable disable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using DataAccess;
using Business;

//Generated from Custom Template.
namespace MVC.Controllers
{
    public class BugsController : Controller
    {
        // TODO: Add service injections here
        private readonly IProjectService _projectService;
        private readonly IBugService _bugService;

        public BugsController(IBugService bugService, IProjectService projectService)
        {
            _bugService = bugService;
            _projectService = projectService;
        }

        // GET: Bugs
        public IActionResult Index()
        {
            List<BugModel> bugList = _bugService.GetList();
            return View(bugList);
        }

        // GET: Bugs/Details/5
        public IActionResult Details(int id)
        {
            BugModel bug = _bugService.GetItem(id);
            if (bug == null)
            {
                return View("_Error", "Bug not found!");
            }
            return View(bug);
        }

        // GET: Bugs/Create
        public IActionResult Create()
        {
            ViewBag.ProjectID = new MultiSelectList(_projectService.Query().ToList(), "ProjectID", "ProjectName");
            return View();
        }

        // POST: Bugs/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(BugModel bug)
        {
            if (ModelState.IsValid)
            {
                var result = _bugService.Add(bug);
                if (result.IsSuccessful)
                {
					TempData["Message"] = result.Message;
					return RedirectToAction(nameof(Index));
                }
                ModelState.AddModelError("", result.Message);
            }
            ViewBag.ProjectID = new MultiSelectList(_projectService.Query().ToList(), "ProjectID", bug.ProjectID.ToString());
			return View(bug);
        }

        // GET: Bugs/Edit/5
        public IActionResult Edit(int id)
        {
            BugModel bug = _bugService.GetItem(id);
            if (bug == null)
            {
                return View("_Error", "Bug not found!");
			}
            ViewBag.ProjectID = new MultiSelectList(_projectService.Query().ToList(), "ProjectID", "ProjectName");
			return View(bug);
        }

        // POST: Bugs/Edit
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(BugModel bug)
        {
            if (ModelState.IsValid)
            {
                var result = _bugService.Update(bug);
                if (result.IsSuccessful)
                {
					TempData["Message"] = result.Message;
                    return RedirectToAction(nameof(Details), new { id = bug.BugID });
				}
                ModelState.AddModelError("", result.Message);
            }
            ViewBag.ProjectID = new MultiSelectList(_projectService.Query().ToList(), "ProjectID", bug.ProjectID.ToString());
			return View(bug);

        }

        // GET: Bugs/Delete/5
        public IActionResult Delete(int id)
        {
            var result = _bugService.Delete(id);
			TempData["Message"] = result.Message;
			return RedirectToAction(nameof(Index));
        }

        // POST: Bugs/Delete
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            // TODO: Add delete service logic here
            return RedirectToAction(nameof(Index));
        }
	}
}
