#nullable disable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using DataAccess;
using Business;

//Generated from Custom Template.
namespace MVC.Controllers
{
    public class ProjectsController : Controller
    {
        // TODO: Add service injections here
        private readonly IProjectService _projectService;
        private readonly IUserService _userService;

        public ProjectsController(IProjectService projectService, IUserService userService)
        {
            _projectService = projectService;
            _userService = userService;
        }

        // GET: Projects
        public IActionResult Index()
        {
            List<ProjectModel> projectList = _projectService.GetList();
            return View(projectList);
        }

        // GET: Projects/Details/5
        public IActionResult Details(int id)
        {
            ProjectModel project = _projectService.GetItem(id);
            if (project == null)
            {
                return View("_Error", "User not found!");
            }
            return View(project);
        }

        // GET: Projects/Create
        public IActionResult Create()
        {
            ViewBag.UserID = new MultiSelectList(_userService.Query().ToList(), "Id", "UserName");
            return View();
        }

        // POST: Projects/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(ProjectModel project)
        {
            if (ModelState.IsValid)
            {
                var result = _projectService.Add(project);
                if (result.IsSuccessful)
                {
					TempData["Message"] = result.Message;
					return RedirectToAction(nameof(Index));
                }
                ModelState.AddModelError("", result.Message);
            }
			ViewBag.UserID = new MultiSelectList(_userService.Query().ToList(), "UserID", "UserName");
			return View(project);
        }

        // GET: Projects/Edit/5
        public IActionResult Edit(int id)
        {
            ProjectModel project = _projectService.GetItem(id);
            if (project == null)
            {
                return View("_Error", "Project not found!");
			}
			ViewBag.UserID = new MultiSelectList(_userService.Query().ToList(), "UserID", "UserName");
			return View(project);
        }

        // POST: Projects/Edit
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(ProjectModel project)
        {
            if (ModelState.IsValid)
            {
                var result = _projectService.Update(project);
                if (result.IsSuccessful)
                {
					TempData["Message"] = result.Message;
                    return RedirectToAction(nameof(Details), new { id = project.ProjectID });
				}
                ModelState.AddModelError("", result.Message);
            }
			ViewBag.UserID = new MultiSelectList(_userService.Query().ToList(), "UserID", "UserName");
			return View(project);
        }

        // GET: Projects/Delete/5
        public IActionResult Delete(int id)
        {
            var result = _projectService.Delete(id);
			TempData["Message"] = result.Message;
			return RedirectToAction(nameof(Index));
        }

        // POST: Projects/Delete
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            // TODO: Add delete service logic here
            return RedirectToAction(nameof(Index));
        }
	}
}
